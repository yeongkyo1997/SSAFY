package com.ssafy.word;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WordCloudApplication {

	public static void main(String[] args) {
		SpringApplication.run(WordCloudApplication.class, args);
	}

}
